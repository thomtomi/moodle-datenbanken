(function () {
  "use strict";

  function toArray(list) {
    return Array.prototype.slice.call(list || []);
  }

  function normaliseText(value) {
    return String(value || "")
      .replace(/\u00a0/g, " ")
      .replace(/\s+/g, " ")
      .trim();
  }

  function hasValueContent(element) {
    if (!element) {
      return false;
    }
    if (normaliseText(element.textContent)) {
      return true;
    }
    return Boolean(element.querySelector("a[href], img, table, video, audio"));
  }

  function groupHasContent(group) {
    var values = toArray(group.querySelectorAll(".lp-value"));
    if (!values.length) {
      return hasValueContent(group);
    }
    return values.some(hasValueContent);
  }

  function isoWeek(dateText) {
    var match = normaliseText(dateText).match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if (!match) {
      return "";
    }
    var date = new Date(Date.UTC(Number(match[1]), Number(match[2]) - 1, Number(match[3])));
    var weekday = date.getUTCDay() || 7;
    date.setUTCDate(date.getUTCDate() + 4 - weekday);
    var yearStart = new Date(Date.UTC(date.getUTCFullYear(), 0, 1));
    return String(Math.ceil(((date - yearStart) / 86400000 + 1) / 7));
  }

  function fieldControl(field) {
    if (!field) {
      return null;
    }
    return field.querySelector("select, textarea, input:not([type='hidden'])");
  }

  function findAddControl(root, fieldName) {
    if (!root || !root.querySelector) {
      return null;
    }
    return fieldControl(root.querySelector("[data-lp-field='" + fieldName + "']"));
  }

  function dispatchControlChange(control) {
    if (!control) {
      return;
    }
    try {
      control.dispatchEvent(new Event("input", { bubbles: true }));
      control.dispatchEvent(new Event("change", { bubbles: true }));
    } catch (error) {
      var changeEvent = document.createEvent("HTMLEvents");
      changeEvent.initEvent("change", true, false);
      control.dispatchEvent(changeEvent);
    }
  }

  function setControlValue(control, value) {
    if (!control) {
      return;
    }
    if (control.tagName && control.tagName.toLowerCase() === "select") {
      var hasOption = toArray(control.options).some(function (option) {
        return option.value === value;
      });
      control.value = hasOption ? value : "";
    } else {
      control.value = value;
    }
    dispatchControlChange(control);
  }

  function updateComputedWeeks(root) {
    toArray(root.querySelectorAll(".lp-plan")).forEach(function (plan) {
      var manualWeek = plan.querySelector(".lp-stored-week");
      var computedWeek = plan.querySelector(".lp-js-week");
      var dateValue = plan.querySelector(".lp-date-value");
      if (!computedWeek || !dateValue) {
        return;
      }
      computedWeek.textContent = "";
      if (hasValueContent(manualWeek)) {
        return;
      }
      var week = isoWeek(dateValue.textContent);
      if (week) {
        computedWeek.textContent = "KW " + week;
      }
    });
  }

  function hideEmptyDisplayGroups(root) {
    var groups = toArray(root.querySelectorAll(".lp-display [data-empty-group]")).reverse();
    groups.forEach(function (group) {
      if (groupHasContent(group)) {
        group.classList.remove("lp-hidden");
      } else {
        group.classList.add("lp-hidden");
      }
    });
  }

  function tidySeparators(root) {
    toArray(root.querySelectorAll(".lp-plan-subtitle, .lp-muted")).forEach(function (line) {
      var visibleValues = toArray(line.querySelectorAll(".lp-value")).filter(function (value) {
        return !value.closest(".lp-hidden") && hasValueContent(value);
      });
      toArray(line.querySelectorAll(".lp-dot")).forEach(function (dot) {
        dot.classList.toggle("lp-hidden", visibleValues.length < 2);
      });
    });
  }

  function setPlaceholders(root) {
    toArray(root.querySelectorAll(".lp-db-add .lp-field[data-placeholder]")).forEach(function (field) {
      var control = field.querySelector("input[type='text'], input[type='url'], textarea");
      if (control && !control.getAttribute("placeholder")) {
        control.setAttribute("placeholder", field.getAttribute("data-placeholder"));
      }
    });
  }

  function controlHasContent(control) {
    if (!control) {
      return false;
    }
    if (control.tagName && control.tagName.toLowerCase() === "select" && control.multiple) {
      return toArray(control.selectedOptions).some(function (option) {
        return normaliseText(option.value) && option.value !== "xxx";
      });
    }
    if (typeof control.value === "string" && normaliseText(control.value)) {
      return true;
    }
    return false;
  }

  function enhanceDateInputs(root) {
    toArray(root.querySelectorAll(".lp-db-add [data-lp-date]")).forEach(function (field) {
      var control = field.querySelector("input:not([type='hidden'])");
      if (!control) {
        return;
      }
      try {
        control.setAttribute("type", "date");
      } catch (error) {
        control.setAttribute("inputmode", "numeric");
      }
    });
  }

  function bindAutoWeeks(root) {
    toArray(root.querySelectorAll(".lp-db-add")).forEach(function (form) {
      if (form.getAttribute("data-lp-week-bound") === "1") {
        return;
      }
      var dateControl = findAddControl(form, "unterrichtsdatum");
      var weekControl = findAddControl(form, "kalenderwoche");
      var output = form.querySelector("[data-lp-week-output]");
      if (!dateControl || !output) {
        return;
      }
      form.setAttribute("data-lp-week-bound", "1");
      var sync = function () {
        var week = isoWeek(dateControl.value);
        var text = week ? "KW " + week : "";
        output.textContent = text;
        if (weekControl) {
          setControlValue(weekControl, text);
        }
      };
      dateControl.addEventListener("input", sync);
      dateControl.addEventListener("change", sync);
      sync();
    });
  }

  function selectHasValue(select, value) {
    return toArray(select.options).some(function (option) {
      return option.value === value;
    });
  }

  function bindLessonSlots(root) {
    toArray(root.querySelectorAll(".lp-db-add [data-lp-slot-select]")).forEach(function (slotSelect) {
      if (slotSelect.getAttribute("data-lp-bound") === "1") {
        return;
      }
      var container = slotSelect.closest(".lp-db-add");
      var startControl = findAddControl(container, slotSelect.getAttribute("data-lp-target-start"));
      var endControl = findAddControl(container, slotSelect.getAttribute("data-lp-target-end"));
      if (!startControl || !endControl) {
        return;
      }
      slotSelect.setAttribute("data-lp-bound", "1");
      var syncSlotFromControls = function () {
        var value = normaliseText(startControl.value) && normaliseText(endControl.value)
          ? startControl.value + "|" + endControl.value
          : "";
        slotSelect.value = selectHasValue(slotSelect, value) ? value : "";
      };
      slotSelect.addEventListener("change", function () {
        var parts = slotSelect.value.split("|");
        setControlValue(startControl, parts[0] || "");
        setControlValue(endControl, parts[1] || "");
      });
      startControl.addEventListener("change", syncSlotFromControls);
      endControl.addEventListener("change", syncSlotFromControls);
      syncSlotFromControls();
    });
  }

  function enhanceTopicPicker(root) {
    toArray(root.querySelectorAll(".lp-db-add [data-lp-topic-picker]")).forEach(function (field) {
      if (field.getAttribute("data-lp-enhanced") === "1") {
        return;
      }
      var select = field.querySelector("select[multiple]");
      if (!select) {
        return;
      }
      field.setAttribute("data-lp-enhanced", "1");
      var picker = document.createElement("div");
      picker.className = "lp-chip-picker";
      picker.setAttribute("role", "group");
      var buttons = [];
      var syncButtons = function () {
        buttons.forEach(function (button) {
          var option = button.lpOption;
          button.classList.toggle("is-selected", option.selected);
          button.setAttribute("aria-pressed", option.selected ? "true" : "false");
        });
      };
      toArray(select.options).forEach(function (option) {
        if (!normaliseText(option.value)) {
          return;
        }
        var button = document.createElement("button");
        button.type = "button";
        button.className = "lp-topic-chip";
        button.textContent = option.textContent;
        button.lpOption = option;
        button.addEventListener("click", function () {
          option.selected = !option.selected;
          syncButtons();
          dispatchControlChange(select);
        });
        buttons.push(button);
        picker.appendChild(button);
      });
      select.classList.add("lp-native-select-hidden");
      select.parentNode.insertBefore(picker, select.nextSibling);
      select.addEventListener("change", syncButtons);
      syncButtons();
    });
  }

  function setLearningGoalStarter(root) {
    toArray(root.querySelectorAll(".lp-db-add [data-lp-prefill]")).forEach(function (field) {
      var value = field.getAttribute("data-lp-prefill") || "";
      var textarea = field.querySelector("textarea");
      var editor = field.querySelector("[contenteditable='true']");
      if (textarea && !controlHasContent(textarea)) {
        textarea.value = value;
        dispatchControlChange(textarea);
      }
      if (editor && !normaliseText(editor.textContent)) {
        editor.textContent = value;
        dispatchControlChange(editor);
      }
    });
  }

  function openFilledDetails(root) {
    toArray(root.querySelectorAll(".lp-db-add details[data-open-if-filled]")).forEach(function (details) {
      var controls = toArray(details.querySelectorAll("input, textarea, select"));
      if (controls.some(controlHasContent)) {
        details.setAttribute("open", "open");
      }
    });
  }

  function init() {
    var root = document;
    updateComputedWeeks(root);
    hideEmptyDisplayGroups(root);
    tidySeparators(root);
    setPlaceholders(root);
    enhanceDateInputs(root);
    setLearningGoalStarter(root);
    bindAutoWeeks(root);
    bindLessonSlots(root);
    enhanceTopicPicker(root);
    openFilledDetails(root);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
  window.setTimeout(init, 500);
  window.setTimeout(init, 1500);
})();
